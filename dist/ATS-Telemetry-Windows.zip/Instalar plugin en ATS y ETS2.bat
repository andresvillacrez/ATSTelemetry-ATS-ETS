@echo off
setlocal
cd /d "%~dp0"
if not exist "install-plugin.bat" (
    echo No se encontro install-plugin.bat en esta carpeta.
    pause
    exit /b 1
)
call "install-plugin.bat"
exit /b %errorlevel%