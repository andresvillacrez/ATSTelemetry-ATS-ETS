@echo off
setlocal
cd /d "%~dp0"
if not exist "ATSTelemetry.exe" (
    echo No se encontro ATSTelemetry.exe en esta carpeta.
    pause
    exit /b 1
)
start "" "ATSTelemetry.exe" --demo
exit /b 0